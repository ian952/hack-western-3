$(function() {
  new Dragdealer('simple-slider');
})
