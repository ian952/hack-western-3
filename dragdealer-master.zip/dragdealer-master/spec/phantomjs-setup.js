$(function() {
  // for some reasone, jasmine-jquery expects exactly this container for the fixtures...
  $("body").append($("<div id=\"content\"><div class=\"slide specs\"></div><div>"));
})
  
